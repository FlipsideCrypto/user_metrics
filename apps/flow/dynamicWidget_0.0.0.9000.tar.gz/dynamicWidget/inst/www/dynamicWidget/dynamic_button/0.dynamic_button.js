(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ "./node_modules/@dynamic-labs/sdk-react-core/src/lib/widgets/DynamicBridgeWidget/views/EditProfileView/EditProfileView.js":
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/@dynamic-labs/sdk-react-core/src/lib/widgets/DynamicBridgeWidget/views/EditProfileView/EditProfileView.js ***!
  \********************************************************************************************************************************/
/*! exports provided: EditProfileView, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditProfileView", function() { return EditProfileView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EditProfileView; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

var EditProfileView = function EditProfileView() {
  return Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("p", {
    children: "Edit Profile View"
  });
};


/***/ })

}]);
//# sourceMappingURL=0.dynamic_button.js.map