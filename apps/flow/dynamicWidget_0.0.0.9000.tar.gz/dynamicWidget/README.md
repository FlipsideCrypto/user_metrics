# Working with the Dynamic Integration

## Getting Started

1.  Install Language Dependencies

Before you do anything, you are going to have to install everything that is needed to make our `R` packages work. After running this, you should be able to go open a terminal and type `R` to receive a help response.

```bash
brew install R libgit2 harfbuzz fribidi libtiff  
```

> **Note**
> This is a global install it does not matter where you run this command if you copy-paste the above.* 

> **Important**
> If you are on MacOS, you are likely to have an issue with installing R that can be resolved by running the following in your terminal (again, this is global):
> 
> ```bash
> brew update && brew upgrade
> brew reinstall gcc
> brew reinstall r
> ```

1.  Install Repository Package References



 ```
 Rscript setup.R
 ```

3.  in the terminal create an R project with react?

```
path <- file.path(getwd(), "flowAttestR")
usethis::create_package(path)
reactR::scaffoldReactShinyInput(
  "wallet_connect", 
  list(
    "reactstrap" = "^8.9.0"
  )
)
quit()

Save workspace image? [y/n/c]: n
yarn install

```
## "exporting"

R doesn't call it that but that's what we're doing

```

cd <my library to export>
yarn run webpack --mode=development 
R
devtools::document()
devtools::load_all()
-or-
devtools::install()
```


## Running

```
cd <this directory>
 R -e "shiny::runApp('.')"
```
